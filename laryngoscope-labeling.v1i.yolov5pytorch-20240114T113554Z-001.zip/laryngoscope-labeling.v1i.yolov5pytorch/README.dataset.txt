# laryngoscope-labeling > 2023-06-10 7:31pm
https://universe.roboflow.com/sidharth-kaushik-dwfrb/laryngoscope-labeling

Provided by a Roboflow user
License: CC BY 4.0

